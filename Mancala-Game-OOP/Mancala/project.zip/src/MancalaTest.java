/**
 * @author mahmudaakter
 * @author rohansurana
 * Tester Class
 */
public class MancalaTest {
    /**
     * Main method, creates a new instance of FirstScreen.
     *
     * @param args
     */
    public static void main(String[] args) {
        FirstScreen fs = new FirstScreen();
    }
}
